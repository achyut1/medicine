package com.drona.implementation;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.drona.beans.Medicine;
import com.drona.dao.MedicineDAO;

@Repository
public class MedicineDAOImpl implements MedicineDAO
{
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template)
	{
		this.template = template;
	}

	public int save(Medicine p)
	{
		Date date = new Date();
		String sql = "insert into Medicine(name,Manufacturing_date,expiry_date,price,quantity,quantity_available,created_on) values('" + p.getName() + "','"
				+ p.getManufacturingDate() + "','" + p.getExpiryDate() + "'," + p.getPrice() + "," + p.getQuantity() + "," + p.getQuantityAvailable() + ",'"
				+ date.toString() + "')";
		return template.update(sql);
	}

	public int update(Medicine p, int id)
	{
		String sql = "update Medicine set " + "name='" + p.getName() + "', " + "Manufacturing_date='" + p.getManufacturingDate() + "', " + "expiry_date='"
				+ p.getExpiryDate() + "', " + "price=" + p.getPrice() + ", " + "quantity=" + p.getQuantity() + ", " + "quantity_available="
				+ p.getQuantityAvailable() + " " + " where id=" + id;
		return template.update(sql);
	}

	public int delete(int id)
	{
		String sql = "delete from Medicine where id=" + id + "";
		return template.update(sql);
	}

	public Medicine getMedicineById(int id)
	{
		String sql = "select * from Medicine where id=?";
		return template.queryForObject(sql, new Object[]
		{
			id
		}, new BeanPropertyRowMapper<Medicine>(Medicine.class));
	}

	public List<Medicine> getMedicines()
	{
		return template.query("select * from Medicine", new RowMapper<Medicine>()
		{
			public Medicine mapRow(ResultSet rs, int row) throws SQLException
			{
				Medicine e = new Medicine();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setManufacturingDate(rs.getString(3));
				e.setExpiryDate(rs.getString(4));
				e.setPrice(rs.getInt(5));
				e.setQuantity(rs.getInt(6));
				e.setQuantityAvailable(rs.getInt(7));
				e.setCreatedOn(rs.getString(8));
				return e;
			}
		});
	}
}