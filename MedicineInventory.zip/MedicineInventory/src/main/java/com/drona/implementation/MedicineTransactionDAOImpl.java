package com.drona.implementation;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.drona.beans.MedicineTransaction;
import com.drona.dao.MedicineTransactionDAO;

@Repository
public class MedicineTransactionDAOImpl implements MedicineTransactionDAO
{
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template)
	{
		this.template = template;
	}

	public int save(MedicineTransaction p)
	{
		Date date = new Date();
		String sql = "insert into Medicine_Transaction(medicine_id,quantity_sold,transaction_date) values(" + p.getMedicineId() + "," + p.getQuantitySold() + ",'"
				+ date.toString() + "')";
		return template.update(sql);
	}

	public int update(MedicineTransaction p)
	{
		Date date = new Date();
		String sql = "update Medicine_Transaction set " + "medicine_id=" + p.getMedicineId() + ", " + "quantity_sold=" + p.getQuantitySold() + ", "
				+ "transaction_date='" + date.toString() + "' where id=" + p.getId();
		return template.update(sql);
	}

	public int delete(int id)
	{
		String sql = "delete from Medicine_Transaction where id=" + id + "";
		return template.update(sql);
	}

	public MedicineTransaction getMedicineTransactionById(int id)
	{
		String sql = "select * from Medicine_Transaction where id=?";
		return template.queryForObject(sql, new Object[]
		{
			id
		}, new BeanPropertyRowMapper<MedicineTransaction>(MedicineTransaction.class));
	}

	public List<MedicineTransaction> getMedicineTransactions()
	{
		return template.query("select * from Medicine_Transaction", new RowMapper<MedicineTransaction>()
		{
			public MedicineTransaction mapRow(ResultSet rs, int row) throws SQLException
			{
				MedicineTransaction e = new MedicineTransaction();
				e.setId(rs.getInt(1));
				e.setMedicineId(rs.getInt(2));
				e.setQuantitySold(rs.getInt(3));
				e.setTransactionDate(rs.getString(4));
				return e;
			}
		});
	}

	public List<MedicineTransaction> getMedicineTransactionsByMedicineId(int medicineId)
	{
		return template.query("select * from Medicine_Transaction where medicine_id=" + medicineId + "", new RowMapper<MedicineTransaction>()
		{
			public MedicineTransaction mapRow(ResultSet rs, int row) throws SQLException
			{
				MedicineTransaction e = new MedicineTransaction();
				e.setId(rs.getInt(1));
				e.setMedicineId(rs.getInt(2));
				e.setQuantitySold(rs.getInt(3));
				e.setTransactionDate(rs.getString(4));
				return e;
			}
		});
	}
}