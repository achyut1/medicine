package com.drona.implementation;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.drona.beans.Users;
import com.drona.dao.UsersDAO;

@Repository
public class UsersDAOImpl implements UsersDAO
{
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template)
	{
		this.template = template;
	}
	
	public int save(Users p)
	{
		String sql = "insert into Users(name,address,Email,Phone_Number,Password) values('" + p.getName() + "','" + p.getAddress() + "','" + p.getEmail() + "','"
				+ p.getPhoneNumber() + "','" + p.getPassword() + "')";
		return template.update(sql);
	}

	public int update(Users p)
	{
		String sql = "update Users set name='" + p.getName() + "', address='" + p.getAddress() + "',Email='" + p.getEmail() + "',Phone_Number='" + p.getPhoneNumber()
				+ "',Password='" + p.getPassword() + "' where id=" + p.getId() + "";
		return template.update(sql);
	}

	public int delete(int id)
	{
		String sql = "delete from Users where id=" + id + "";
		return template.update(sql);
	}

	public Users getUserById(int id)
	{
		String sql = "select * from Users where id=?";
		return template.queryForObject(sql, new Object[]
		{
			id
		}, new BeanPropertyRowMapper<Users>(Users.class));
	}

	public List<Users> getUsers()
	{
		return template.query("select * from Users", new RowMapper<Users>()
		{
			public Users mapRow(ResultSet rs, int row) throws SQLException
			{
				Users e = new Users();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setAddress(rs.getString(3));
				e.setEmail(rs.getString(4));
				e.setPhoneNumber(rs.getString(5));
				e.setPassword(rs.getString(6));
				return e;
			}
		});
	}
}