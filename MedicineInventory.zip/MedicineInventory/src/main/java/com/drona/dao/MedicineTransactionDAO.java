package com.drona.dao;

import java.util.List;

import com.drona.beans.MedicineTransaction;

public interface MedicineTransactionDAO
{
	public int save(MedicineTransaction p);

	public int update(MedicineTransaction p);

	public int delete(int id);

	public MedicineTransaction getMedicineTransactionById(int id);

	public List<MedicineTransaction> getMedicineTransactions();

	public List<MedicineTransaction> getMedicineTransactionsByMedicineId(int medicineId);
}