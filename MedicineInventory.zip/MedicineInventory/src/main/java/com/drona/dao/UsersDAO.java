package com.drona.dao;

import java.util.List;

import com.drona.beans.Users;

public interface UsersDAO
{
	public int save(Users p);

	public int update(Users p);

	public int delete(int id);

	public Users getUserById(int id);

	public List<Users> getUsers();
}