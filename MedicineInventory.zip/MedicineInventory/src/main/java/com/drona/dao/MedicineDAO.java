package com.drona.dao;

import java.util.List;

import com.drona.beans.Medicine;

public interface MedicineDAO
{
	public int save(Medicine p);

	public int update(Medicine p, int id);

	public int delete(int id);

	public Medicine getMedicineById(int id);

	public List<Medicine> getMedicines();
}