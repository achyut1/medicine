package com.drona.beans;

public class MedicineTransaction
{
	private int		id;
	private int		medicineId;
	private int		quantitySold;
	private String	transactionDate;

	public MedicineTransaction()
	{
		super();
	}

	public MedicineTransaction(int id, int medicineId, int quantitySold, String transactionDate)
	{
		super();
		this.id = id;
		this.medicineId = medicineId;
		this.quantitySold = quantitySold;
		this.transactionDate = transactionDate;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getMedicineId()
	{
		return medicineId;
	}

	public void setMedicineId(int medicineId)
	{
		this.medicineId = medicineId;
	}

	public int getQuantitySold()
	{
		return quantitySold;
	}

	public void setQuantitySold(int quantitySold)
	{
		this.quantitySold = quantitySold;
	}

	public String getTransactionDate()
	{
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate)
	{
		this.transactionDate = transactionDate;
	}

	public String toString()
	{
		return "MedicineTransaction [id=" + id + ", medicineId=" + medicineId + ", quantitySold=" + quantitySold + ", transactionDate=" + transactionDate + "]";
	}
}