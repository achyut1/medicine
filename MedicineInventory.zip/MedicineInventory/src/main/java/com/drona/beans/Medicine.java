package com.drona.beans;

public class Medicine
{
	private int		id;
	private String	name;
	private String	manufacturingDate;
	private String	expiryDate;
	private int		price;
	private int		quantity;
	private int		quantityAvailable;
	private String	createdOn;

	public Medicine()
	{
		super();
	}

	public Medicine(int id, String name, String manufacturingDate, String expiryDate, int price, int quantity, int quantityAvailable, String createdOn)
	{
		super();
		this.id = id;
		this.name = name;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
		this.price = price;
		this.quantity = quantity;
		this.quantityAvailable = quantityAvailable;
		this.createdOn = createdOn;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getManufacturingDate()
	{
		return manufacturingDate;
	}

	public void setManufacturingDate(String manufacturingDate)
	{
		this.manufacturingDate = manufacturingDate;
	}

	public String getExpiryDate()
	{
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate)
	{
		this.expiryDate = expiryDate;
	}

	public int getPrice()
	{
		return price;
	}

	public void setPrice(int price)
	{
		this.price = price;
	}

	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}

	public int getQuantityAvailable()
	{
		return quantityAvailable;
	}

	public void setQuantityAvailable(int quantityAvailable)
	{
		this.quantityAvailable = quantityAvailable;
	}

	public String getCreatedOn()
	{
		return createdOn;
	}

	public void setCreatedOn(String createdOn)
	{
		this.createdOn = createdOn;
	}

	public String toString()
	{
		return "Medicine [id=" + id + ", name=" + name + ", manufacturingDate=" + manufacturingDate + ", expiryDate=" + expiryDate + ", price=" + price
				+ ", quantity=" + quantity + ", quantityAvailable=" + quantityAvailable + ", createdOn=" + createdOn + "]";
	}
}