package com.drona.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.drona.beans.Medicine;
import com.drona.dao.MedicineDAO;

@RestController
public class MedicineController
{
	@Autowired
	MedicineDAO medicineDAO;

	@RequestMapping(value = "/getMedicineDetails", method = RequestMethod.GET, produces = "application/json")
	public List<Medicine> getMedicineDetails()
	{
		List<Medicine> list = medicineDAO.getMedicines();
		return list;
	}

	@RequestMapping(value = "/getMedicineDetailsById/{id}", method = RequestMethod.GET, produces = "application/json")
	public Medicine getMedicineDetailsById(@PathVariable int id)
	{
		Medicine medicine = medicineDAO.getMedicineById(id);
		return medicine;
	}

	@RequestMapping(value = "/addMedicineDetails", method = RequestMethod.POST)
	public Medicine addMedicineDetails(@RequestBody Medicine medicine)
	{
		medicineDAO.save(medicine);
		return medicine;
	}

	@RequestMapping(value = "/updateMedicineDetails/{id}", method = RequestMethod.PUT)
	public Medicine updateMedicineDetails(@RequestBody Medicine medicine, @PathVariable("id") int id)
	{
		medicineDAO.update(medicine, id);
		medicine.setId(id);
		return medicine;
	}

	@RequestMapping(value = "/deleteMedicineDetails/{id}", method = RequestMethod.DELETE)
	public void deleteMedicineDetails(@PathVariable("id") int id)
	{
		medicineDAO.delete(id);
	}
}