package com.drona.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.drona.dao.MedicineTransactionDAO;

@RestController
public class MedicineTransactionController
{
	@Autowired
	MedicineTransactionDAO medicineTransactionDAO;

}