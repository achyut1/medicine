package com.drona.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.drona.beans.Users;
import com.drona.dao.UsersDAO;

@RestController
public class UsersController
{
	@Autowired
	UsersDAO usersDAO;
	
	@RequestMapping(value = "/getUsers", method = RequestMethod.GET, produces = "application/json")
	public List<Users> getUsers()
	{
		List<Users> list = usersDAO.getUsers();
		return list;
	}

	@RequestMapping(value = "/getUserDetailsById/{id}", method = RequestMethod.GET, produces = "application/json")
	public Users getUserDetailsById(@PathVariable int id)
	{
		Users User = usersDAO.getUserById(id);
		return User;
	}

	@RequestMapping(value = "/addUserDetails", method = RequestMethod.POST)
	public Users addUserDetails(@RequestBody Users user)
	{
		usersDAO.save(user);
		return user;
	}

	@RequestMapping(value = "/updateUserDetails", method = RequestMethod.PUT)
	public Users updateMedicineDetails(@RequestBody Users user)
	{
		usersDAO.update(user);
		return user;
	}

	@RequestMapping(value = "/deleteUserDetails/{id}", method = RequestMethod.DELETE)
	public void deleteUserDetails(@PathVariable("id") int id)
	{
		usersDAO.delete(id);
	}
}