export interface Medicine {
	id: number;
    name: string;
    manufacturingDate: string;
	expiryDate: string;
	price: number;
	quantity: number;
	quantityAvailable: number;
	createdOn: string;
}
