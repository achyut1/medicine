import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
   
import {  Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
  
import { Medicine } from './medicine';
   
@Injectable({
  providedIn: 'root'
})
export class MedicineService {
   
  private apiURL = "http://localhost:8080/MedicineInventory";
   
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  
  constructor(private httpClient: HttpClient) { }
   
  getAll(): Observable<Medicine[]> {
    return this.httpClient.get<Medicine[]>(this.apiURL + '/getMedicineDetails/')
    .pipe(
      catchError(this.errorHandler)
    )
  }
  
  find(id): Observable<Medicine> {
    return this.httpClient.get<Medicine>(this.apiURL + '/getMedicineDetailsById/' + id)
    .pipe(
      catchError(this.errorHandler)
    )
  }
  
  create(medicine): Observable<Medicine> {
    return this.httpClient.post<Medicine>(this.apiURL + '/addMedicineDetails/', JSON.stringify(medicine), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }  
   
  update(id, medicine): Observable<Medicine> {
    return this.httpClient.put<Medicine>(this.apiURL + '/updateMedicineDetails/' + id, JSON.stringify(medicine), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  delete(id){
    return this.httpClient.delete<Medicine>(this.apiURL + '/deleteMedicineDetails/' + id, this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
    
  
  errorHandler(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }
}