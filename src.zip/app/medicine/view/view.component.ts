import { Component, OnInit } from '@angular/core';
import { MedicineService } from '../medicine.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Medicine } from '../medicine';
  
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
   
  id: number;
  medicine: Medicine;
   
  constructor(
    public medicineService: MedicineService,
    private route: ActivatedRoute,
    private router: Router
   ) { }
  
  ngOnInit(): void {
    this.id = this.route.snapshot.params['medicineId'];
      
    this.medicineService.find(this.id).subscribe((data: Medicine)=>{
      this.medicine = data;
    });
  }
  
}