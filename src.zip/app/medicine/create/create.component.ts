import { Component, OnInit } from '@angular/core';
import { MedicineService } from '../medicine.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
   
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  
  //medicineForm: FormGroup;
  
  medicineForm = new FormGroup({
    name : new FormControl(),
    manufacturingDate : new FormControl(),
    expiryDate : new FormControl(),
    price : new FormControl(),
    quantity : new FormControl(),
    quantityAvailable : new FormControl()
  });
   
  constructor(
    public medicineService: MedicineService,
    private router: Router
  ) { }
  
  ngOnInit(): void {
    //this.medicineForm = new FormGroup({
    //  title: new FormControl('', [Validators.required]),
    //  body: new FormControl('', Validators.required)
    //});
  }
    
  submit(){
    console.log(this.medicineForm.value);
    this.medicineService.create(this.medicineForm.value).subscribe(res => {
         console.log('Medicine created successfully!');
         this.router.navigateByUrl('medicine/index');
    })
  }
  
}