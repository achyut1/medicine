import { Component, OnInit } from '@angular/core';
import { MedicineService } from '../medicine.service';
import { Medicine } from '../medicine';
  
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
   
  medicines: Medicine[] = [];
  
  constructor(public medicineService: MedicineService) { }
  
  ngOnInit(): void {
    this.medicineService.getAll().subscribe((data: Medicine[])=>{
      this.medicines = data;
      console.log(this.medicines);
    })  
  }
  
  deleteMedicine(id){
    this.medicineService.delete(id).subscribe(res => {
         this.medicines = this.medicines.filter(item => item.id !== id);
         console.log('Medicine deleted successfully!');
    })
  }
  
}