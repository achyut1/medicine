import { Component, OnInit } from '@angular/core';
import { MedicineService } from '../medicine.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Medicine } from '../medicine';
import { FormGroup, FormControl, Validators} from '@angular/forms';
   
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  id: number;
  medicine: Medicine;
  
  //medicineForm: FormGroup;
  medicineForm = new FormGroup({
    name : new FormControl(),
    manufacturingDate : new FormControl(),
    expiryDate : new FormControl(),
    price : new FormControl(),
    quantity : new FormControl(),
    quantityAvailable : new FormControl()
  });
  
  constructor(
    public medicineService: MedicineService,
    private route: ActivatedRoute,
    private router: Router
  ) { }
  
  ngOnInit(): void {
    this.id = this.route.snapshot.params['medicineId'];
    this.medicineService.find(this.id).subscribe((data: Medicine)=>{
      this.medicine = data;
	  console.log(this.medicine);
    });
    
    //this.medicineForm = new FormGroup({
    //  title: new FormControl('', [Validators.required]),
    //  body: new FormControl('', Validators.required)
    //});
  }
     
  submit(){
    console.log(this.medicineForm.value);
    this.medicineService.update(this.id, this.medicineForm.value).subscribe(res => {
         console.log('Medicine updated successfully!');
         this.router.navigateByUrl('medicine/index');
    })
  }
   
}